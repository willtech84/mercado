# Lista de Compras 1.2.5 (PWA)
- Funciona offline (Service Worker)
- Suporte a código de barras via câmera (BarcodeDetector) em HTTPS
- Armazena dados no LocalStorage

## GitHub Pages
Settings → Pages → Deploy from branch → Branch: main /root

## Netlify
New site from Git → selecione o repositório → Publish directory: .
Build command: (vazio)
